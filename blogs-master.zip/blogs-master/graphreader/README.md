# GraphReader implementation

link to paper: https://arxiv.org/abs/2406.14550
