# Copyright (c) 2024 Microsoft Corporation.
# Licensed under the MIT License

"""Persona, entity type, relationships and domain generation prompts module."""
