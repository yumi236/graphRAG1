# About

This document (Operation Dulce) in an AI-generated science fiction novella, included here for the purposes of integration testing.